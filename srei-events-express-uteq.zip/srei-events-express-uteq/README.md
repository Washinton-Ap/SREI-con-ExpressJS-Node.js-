# SREI - Sistema de Registro de Eventos Interculturales (Express + PostgreSQL)

## Cambios incluidos
- Registro para **todos** los usuarios (DOCENTE / COORDINADOR / ESTUDIANTE).
- Validación de correo: `nameapellido@uteq.edu.ec` (solo letras minúsculas antes del @).
- Coordinación con **3 estados**: `PENDING`, `APPROVED`, `REJECTED` (No aprobado).
- Coordinador registra **observaciones** cuando rechaza.
- Docente puede **corregir y reenviar** (REJECTED → PENDING).
- Subida de **imagen** del evento (Multer) y visualización en la UI.

## Requisitos
- Node.js 18+
- PostgreSQL

## 1) Crear base de datos
En pgAdmin o psql:
```sql
CREATE DATABASE srei_events;
```

## 2) Crear tablas
Desde la carpeta del proyecto:
```powershell
psql -U postgres -d srei_events -f db\init.sql
```

## 3) Configurar variables de entorno
```powershell
copy .env.example .env
```
Edita `.env` si tu DB tiene otros datos.

## 4) Instalar dependencias
```powershell
npm install
```

## 5) Ejecutar
```powershell
npm start
```
Abrir:
- http://localhost:3000

## Flujo de prueba rápido
1. Registra un **DOCENTE** (correo UTEQ) y crea un evento (queda **PENDING**).
2. Registra un **COORDINADOR** y aprueba o rechaza con observaciones.
3. Registra un **ESTUDIANTE** y mira solo los eventos **APPROVED** y marca asistencia.

> Nota: en un sistema real, el rol COORDINADOR normalmente lo asigna un ADMIN.
