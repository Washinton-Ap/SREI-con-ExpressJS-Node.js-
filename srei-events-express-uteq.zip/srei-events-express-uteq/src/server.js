require("dotenv").config();
const express = require("express");
const path = require("path");
const cookieParser = require("cookie-parser");

const { attachUser } = require("./middlewares/auth");
const authRoutes = require("./routes/auth.routes");
const eventRoutes = require("./routes/events.routes");

const app = express();

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());

// estáticos (CSS + uploads)
app.use(express.static(path.join(process.cwd(), "public")));

// user en req/res.locals
app.use(attachUser);

app.get("/", (req, res) => {
  if (!req.user) return res.redirect("/login");
  if (req.user.role === "DOCENTE") return res.redirect("/docente/events");
  if (req.user.role === "COORDINADOR") return res.redirect("/coordinador/events");
  return res.redirect("/estudiante/events");
});

app.use(authRoutes);
app.use(eventRoutes);

app.use((req, res) => {
  res.status(404).render("pages/message", { title:"No encontrado", message:"La página no existe.", backHref:"/" });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).render("pages/message", {
    title:"Error",
    message: err.message || "Error inesperado",
    backHref:"javascript:history.back()"
  });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`SREI listo en http://localhost:${port}`));
