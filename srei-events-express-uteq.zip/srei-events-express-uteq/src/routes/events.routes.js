const express = require("express");
const db = require("../db");
const { authRequired, requireRole } = require("../middlewares/auth");
const upload = require("../middlewares/upload");

const router = express.Router();

// DOCENTE
router.get("/docente/events", authRequired, requireRole("DOCENTE"), async (req, res) => {
  const { rows } = await db.query(
    `SELECT * FROM events WHERE created_by=$1 ORDER BY created_at DESC`,
    [req.user.id]
  );
  res.render("pages/docente_events", { events: rows });
});

router.get("/docente/events/new", authRequired, requireRole("DOCENTE"), (req, res) => {
  res.render("pages/docente_event_form", {
    mode: "create",
    event: { title:"", location:"", date_time:"", description:"", image_path:null },
    error: null
  });
});

router.post("/docente/events", authRequired, requireRole("DOCENTE"), upload.single("image"), async (req, res) => {
  const { title, location, date_time, description } = req.body;
  const imagePath = req.file ? `/uploads/${req.file.filename}` : null;

  if (!title || !location || !date_time || !description) {
    return res.status(400).render("pages/docente_event_form", {
      mode: "create",
      event: { title, location, date_time, description, image_path:imagePath },
      error: "Completa todos los campos."
    });
  }

  await db.query(
    `INSERT INTO events (title, location, date_time, description, created_by, status, image_path)
     VALUES ($1,$2,$3,$4,$5,'PENDING',$6)`,
    [title, location, date_time, description, req.user.id, imagePath]
  );

  res.redirect("/docente/events");
});

router.get("/docente/events/:id/edit", authRequired, requireRole("DOCENTE"), async (req, res) => {
  const { id } = req.params;
  const { rows } = await db.query(`SELECT * FROM events WHERE id=$1 AND created_by=$2`, [id, req.user.id]);
  const event = rows[0];
  if (!event) return res.status(404).render("pages/message", { title:"No encontrado", message:"Evento no existe.", backHref:"/docente/events" });

  if (!["PENDING","REJECTED"].includes(event.status)) {
    return res.status(403).render("pages/message", { title:"No permitido", message:"Solo puedes editar si está PENDING o REJECTED.", backHref:"/docente/events" });
  }

  const dt = new Date(event.date_time);
  const iso = new Date(dt.getTime() - dt.getTimezoneOffset()*60000).toISOString().slice(0,16);

  res.render("pages/docente_event_form", { mode:"edit", event:{...event, date_time: iso }, error:null });
});

router.post("/docente/events/:id/edit", authRequired, requireRole("DOCENTE"), upload.single("image"), async (req, res) => {
  const { id } = req.params;
  const { title, location, date_time, description } = req.body;
  const img = req.file ? `/uploads/${req.file.filename}` : null;

  const { rows } = await db.query(
    `UPDATE events
     SET title=$1, location=$2, date_time=$3, description=$4,
         image_path=COALESCE($5, image_path)
     WHERE id=$6 AND created_by=$7 AND status IN ('PENDING','REJECTED')
     RETURNING *`,
    [title, location, date_time, description, img, id, req.user.id]
  );

  if (!rows[0]) return res.status(403).render("pages/message", { title:"No permitido", message:"No se pudo editar (revisa estado/permisos).", backHref:"/docente/events" });

  res.redirect("/docente/events");
});

router.post("/docente/events/:id/delete", authRequired, requireRole("DOCENTE"), async (req, res) => {
  const { id } = req.params;
  const { rowCount } = await db.query(
    `DELETE FROM events WHERE id=$1 AND created_by=$2 AND status IN ('PENDING','REJECTED')`,
    [id, req.user.id]
  );
  if (!rowCount) return res.status(403).render("pages/message", { title:"No permitido", message:"Solo puedes eliminar si está PENDING o REJECTED.", backHref:"/docente/events" });
  res.redirect("/docente/events");
});

router.post("/docente/events/:id/resubmit", authRequired, requireRole("DOCENTE"), async (req, res) => {
  const { id } = req.params;
  const { rowCount } = await db.query(
    `UPDATE events SET status='PENDING' WHERE id=$1 AND created_by=$2 AND status='REJECTED'`,
    [id, req.user.id]
  );
  if (!rowCount) return res.status(400).render("pages/message", { title:"No aplica", message:"Solo puedes reenviar eventos en REJECTED.", backHref:"/docente/events" });
  res.redirect("/docente/events");
});

// COORDINADOR
router.get("/coordinador/events", authRequired, requireRole("COORDINADOR"), async (req, res) => {
  const { rows } = await db.query(
    `SELECT e.*, u.full_name AS docente_name, u.email AS docente_email
     FROM events e JOIN users u ON u.id=e.created_by
     ORDER BY CASE e.status WHEN 'PENDING' THEN 0 WHEN 'REJECTED' THEN 1 ELSE 2 END, e.created_at DESC`
  );
  res.render("pages/coordinador_events", { events: rows });
});

router.post("/coordinador/events/:id/approve", authRequired, requireRole("COORDINADOR"), async (req, res) => {
  const { id } = req.params;
  await db.query(
    `UPDATE events SET status='APPROVED', coordinator_observations=NULL WHERE id=$1 AND status='PENDING'`,
    [id]
  );
  res.redirect("/coordinador/events");
});

router.post("/coordinador/events/:id/reject", authRequired, requireRole("COORDINADOR"), async (req, res) => {
  const { id } = req.params;
  const observations = (req.body.observations || "").trim() || "Sin observaciones.";
  await db.query(
    `UPDATE events SET status='REJECTED', coordinator_observations=$2 WHERE id=$1 AND status='PENDING'`,
    [id, observations]
  );
  res.redirect("/coordinador/events");
});

// ESTUDIANTE
router.get("/estudiante/events", authRequired, requireRole("ESTUDIANTE"), async (req, res) => {
  const { rows } = await db.query(
    `SELECT e.*,
        EXISTS(SELECT 1 FROM event_attendance a WHERE a.event_id=e.id AND a.user_id=$1) AS already_attending
     FROM events e
     WHERE e.status='APPROVED'
     ORDER BY e.date_time DESC`,
    [req.user.id]
  );
  res.render("pages/estudiante_events", { events: rows });
});

router.post("/estudiante/events/:id/attend", authRequired, requireRole("ESTUDIANTE"), async (req, res) => {
  const { id } = req.params;

  const { rows } = await db.query("SELECT id FROM events WHERE id=$1 AND status='APPROVED'", [id]);
  if (!rows[0]) return res.status(400).render("pages/message", { title:"No disponible", message:"Evento no está aprobado.", backHref:"/estudiante/events" });

  try { await db.query("INSERT INTO event_attendance (event_id, user_id) VALUES ($1,$2)", [id, req.user.id]); } catch {}
  res.redirect("/estudiante/events");
});

module.exports = router;
