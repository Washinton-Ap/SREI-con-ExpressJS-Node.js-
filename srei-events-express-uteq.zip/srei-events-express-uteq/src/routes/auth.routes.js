const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const db = require("../db");
const { validateUteqEmail, validatePassword } = require("../utils/validators");

const router = express.Router();

router.get("/login", (req, res) => {
  if (req.user) return res.redirect("/");
  res.render("pages/login", { error: null });
});

router.post("/login", async (req, res) => {
  const email = (req.body.email || "").trim().toLowerCase();
  const password = req.body.password || "";

  try {
    const { rows } = await db.query("SELECT id, password_hash FROM users WHERE email=$1", [email]);
    const user = rows[0];
    if (!user) return res.status(400).render("pages/login", { error: "Credenciales incorrectas." });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(400).render("pages/login", { error: "Credenciales incorrectas." });

    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: "7d" });
    res.cookie("token", token, { httpOnly: true, sameSite: "lax" });
    return res.redirect("/");
  } catch (e) {
    console.error(e);
    return res.status(500).render("pages/login", { error: "Error interno al iniciar sesión." });
  }
});

router.get("/register", (req, res) => {
  if (req.user) return res.redirect("/");
  res.render("pages/register", { error: null, values: { full_name: "", email: "", role: "ESTUDIANTE" } });
});

router.post("/register", async (req, res) => {
  const full_name = (req.body.full_name || "").trim();
  const email = (req.body.email || "").trim().toLowerCase();
  const role = (req.body.role || "ESTUDIANTE").toUpperCase();
  const password = req.body.password || "";

  const values = { full_name, email, role };

  const emailErr = validateUteqEmail(email);
  if (emailErr) return res.status(400).render("pages/register", { error: emailErr, values });

  if (!full_name || full_name.length < 3) {
    return res.status(400).render("pages/register", { error: "Nombre completo inválido.", values });
  }

  if (!["DOCENTE","COORDINADOR","ESTUDIANTE"].includes(role)) {
    return res.status(400).render("pages/register", { error: "Rol inválido.", values });
  }

  const pwErr = validatePassword(password);
  if (pwErr) return res.status(400).render("pages/register", { error: pwErr, values });

  try {
    const { rows: exists } = await db.query("SELECT id FROM users WHERE email=$1", [email]);
    if (exists[0]) return res.status(400).render("pages/register", { error: "Ese correo ya está registrado.", values });

    const hash = await bcrypt.hash(password, 10);
    const { rows } = await db.query(
      "INSERT INTO users (full_name, email, role, password_hash) VALUES ($1,$2,$3,$4) RETURNING id",
      [full_name, email, role, hash]
    );

    const token = jwt.sign({ userId: rows[0].id }, process.env.JWT_SECRET, { expiresIn: "7d" });
    res.cookie("token", token, { httpOnly: true, sameSite: "lax" });
    return res.redirect("/");
  } catch (e) {
    console.error(e);
    return res.status(500).render("pages/register", { error: "Error interno al registrar.", values });
  }
});

router.post("/logout", (req, res) => {
  res.clearCookie("token");
  res.redirect("/login");
});

module.exports = router;
