function validateUteqEmail(email) {
  if (!email) return "El correo es obligatorio.";
  const lower = email.trim().toLowerCase();

  // Formato solicitado: nameapeliido@uteq.edu.ec
  // En esta demo se valida:
  // - solo letras minúsculas antes del @ (sin puntos, sin números)
  // - dominio exacto @uteq.edu.ec
  const re = /^[a-z]{5,}@uteq\.edu\.ec$/;
  if (!re.test(lower)) {
    return "Correo inválido. Usa: nameapellido@uteq.edu.ec (solo letras minúsculas) y dominio @uteq.edu.ec.";
  }
  return null;
}

function validatePassword(pw) {
  if (!pw || pw.length < 6) return "La contraseña debe tener al menos 6 caracteres.";
  return null;
}

module.exports = { validateUteqEmail, validatePassword };
