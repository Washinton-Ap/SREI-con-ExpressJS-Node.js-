const jwt = require("jsonwebtoken");
const db = require("../db");

function getToken(req) {
  return req.cookies && req.cookies.token ? req.cookies.token : null;
}

async function attachUser(req, res, next) {
  try {
    const token = getToken(req);
    if (!token) {
      req.user = null;
      res.locals.user = null;
      return next();
    }

    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const { rows } = await db.query("SELECT id, full_name, email, role FROM users WHERE id=$1", [payload.userId]);
    const user = rows[0] || null;

    req.user = user;
    res.locals.user = user;
    return next();
  } catch {
    req.user = null;
    res.locals.user = null;
    return next();
  }
}

function authRequired(req, res, next) {
  if (!req.user) return res.redirect("/login");
  return next();
}

function requireRole(role) {
  return (req, res, next) => {
    if (!req.user) return res.redirect("/login");
    if (req.user.role !== role) {
      return res.status(403).render("pages/message", {
        title: "Acceso denegado",
        message: "No tienes permisos para acceder a esta sección.",
        backHref: "/"
      });
    }
    return next();
  };
}

module.exports = { attachUser, authRequired, requireRole };
